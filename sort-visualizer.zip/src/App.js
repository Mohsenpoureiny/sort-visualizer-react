import React, {Component} from "react";
import SortVisualizer from "./Containers/SortVisualizer";

class App extends Component {
    render() {
        return (
            <div className="App">
                <SortVisualizer/>
            </div>
        );
    }

}

export default App;
